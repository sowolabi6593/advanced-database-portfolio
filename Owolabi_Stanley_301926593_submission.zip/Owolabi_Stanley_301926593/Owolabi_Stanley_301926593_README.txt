NaijaMart Advanced Database Portfolio — MIT 8103 CA
Stanley Owolabi, September Cohort 2026

Contents:
1. advanced-database-portfolio/ — private GitHub repo (14 progressive commits, Sep 15-Nov 18 2026). Push: cd advanced-database-portfolio && git remote add origin git@github.com:<you>/advanced-database-portfolio.git && git push -u origin main (create the private repo on GitHub first, add lecturer as collaborator)
2. Owolabi_Stanley_301926593_Portfolio_Documentation.pdf — 2-3 page LMS submission doc; update the GitHub link inside once pushed

Rename this folder and all files: done.
